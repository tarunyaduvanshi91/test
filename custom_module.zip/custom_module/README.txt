using the form alter form drupal core.

using json response class in below url
https://api.drupal.org/api/drupal/vendor%21symfony%21http-foundation%21JsonResponse.php/class/JsonResponse/8.2.x

my previous knowledge help in this module.

taking total time is 1 hour.